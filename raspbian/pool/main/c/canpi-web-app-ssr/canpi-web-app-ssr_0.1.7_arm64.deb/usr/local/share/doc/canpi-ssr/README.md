A web server written in Rust to maintain the configuration files of AutoHotspot
and CanPi packages.

Mark Thornber
MERG Member 3748
merg.org.uk
August 2023
